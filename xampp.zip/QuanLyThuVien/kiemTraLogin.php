<?php

    require "connect.php";


    $taiKhoan = $_POST['taiKhoan'];
    $matKhau = $_POST['matKhau'];


     
  
    $sql = "SELECT quyenHan,maNguoiDung FROM taikhoan WHERE taiKhoan = '$taiKhoan' AND matKhau = '$matKhau'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $maNguoiDung = $row['maNguoiDung'];
    if($row['quyenHan'] == "DG"){   
        $sql1 = "SELECT * FROM docgia WHERE maDocGia = '$maNguoiDung'";
    $result1 = $con->query($sql1);

    if ($result1->num_rows > 0) {
        echo $row['quyenHan']."/".$maNguoiDung;
             }
    }else {
        $sql1 = "SELECT * FROM nhanvien WHERE maNhanVien = '$maNguoiDung'";
    $result1 = $con->query($sql1);

    if ($result1->num_rows > 0) {
        echo $row['quyenHan']."/".$maNguoiDung;
             }
    }

    // echo $row['quyenHan'];
    } else {
    echo "NULL";
    }




  ?>