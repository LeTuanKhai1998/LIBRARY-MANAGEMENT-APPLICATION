<?php

    require "connect.php";


    $key = $_POST['key'];
    // $maNguoiDung = "DG00001";



     class TaiKhoan{
      function TaiKhoan($taiKhoan,$matKhau,$quyenHan,$maNguoiDung){
        $this->taiKhoan = $taiKhoan;
        $this->matKhau = $matKhau;
        $this->quyenHan = $quyenHan;
        $this->maNguoiDung = $maNguoiDung;
      }
    }
  
    $sql = "SELECT * FROM taikhoan";
    $result = $con->query($sql);

    $mangTaiKhoan  = array();



    if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) {
   
        array_push($mangTaiKhoan, new TaiKhoan($row['taiKhoan']
                                            ,$row['matKhau']
                                            ,$row['quyenHan']
                                            ,$row['maNguoiDung']));
                    }
                    if(count($mangTaiKhoan)>0){
                        echo json_encode($mangTaiKhoan);
                    }
                    else{
                        echo "Fail";
                    }
    } else {
    echo "NULL";
    }




  ?>