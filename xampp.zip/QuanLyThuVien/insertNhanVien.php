<?php 
    
    require "connect.php";

   
    $maNhanVien = $_POST['maNhanVien'];
    $ten = $_POST['ten'];
    $chucVu = $_POST['chucVu'];
    $email = $_POST['email'];
    $ngaySinh = $_POST['ngaySinh'];
    $gioiTinh = $_POST['gioiTinh'];
    $soDienThoai = $_POST['soDienThoai'];
    $diaChi = $_POST['diaChi'];
    $ngayVaoLam = $_POST['ngayVaoLam'];
    $anhNhanVien = $_POST['anhNhanVien'];

// $maNhanVien=  "NV002";
// $ten=   "TRương Tố Xuân";
// $email=   "toxuan@gmail.com";
// $chucVu= "Thủ thư";
// $ngaySinh=    "29/04/1998";
// $gioiTinh=  "Nữ";
// $soDienThoai= "01256789521";
// $diaChi=    "quận 12";
// $ngayVaoLam=  "05/01/2019";
// $anhNhanVien= "http://172.16.0.234/QuanLyThuVien/images/JPEG_20190115_032213_.jpg";




if(strlen($maNhanVien) > 0 && strlen($ten) > 0 && strlen($chucVu) > 0  && strlen($email) > 0   && strlen($ngaySinh) > 0 && strlen($gioiTinh) > 0 && strlen($soDienThoai) > 0 && strlen($diaChi) > 0 && strlen($ngayVaoLam) > 0 && strlen($anhNhanVien) > 0 ){

       $query = "INSERT INTO nhanvien VALUES ('$maNhanVien','$ten','$chucVu','$email','$ngaySinh','$gioiTinh','$soDienThoai','$diaChi','$ngayVaoLam','$anhNhanVien')";

        if($con->query($query) === TRUE){
            echo "Succsess";
        }else{
            echo "Error updating record:" . mysqli_error($con);
        }
    }else{
        echo "NULL";
    }








 ?>