<?php

    require "connect.php";


    $key = $_POST['key'];    



     class TheLoai{
      function TheLoai($maTheLoai,$tenTheLoai){
        $this->maTheLoai = $maTheLoai;
        $this->tenTheLoai = $tenTheLoai;
        }
    }

  
    $sql = "SELECT * FROM theloai ";
    $result = $con->query($sql);

    $mangTheLoai  = array();

    if ($result->num_rows > 0) {
   
    while($row = $result->fetch_assoc()) {
        array_push($mangTheLoai, new TheLoai($row['maTheLoai']
                                            ,$row['tenTheLoai']));
        
                    }
                    if(count($mangTheLoai)>0){
                        echo json_encode($mangTheLoai);
                    }
                    else{
                        echo "Fail". mysqli_error($con);
                    }
    } else {
    echo "NULL";
    }





  ?>