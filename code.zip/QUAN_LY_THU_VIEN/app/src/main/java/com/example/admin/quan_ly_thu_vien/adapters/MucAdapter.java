package com.example.admin.quan_ly_thu_vien.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.example.admin.quan_ly_thu_vien.R;
import com.example.admin.quan_ly_thu_vien.activitys.BienToanCuc;
import com.example.admin.quan_ly_thu_vien.fragments.DauSachFragment;
import com.example.admin.quan_ly_thu_vien.fragments.DocGiaFragment;
import com.example.admin.quan_ly_thu_vien.fragments.NhanVienFragment;

public class MucAdapter extends SmartFragmentStatePagerAdapter {
    private Context mContext;
    private static int NUM_ITEMS = 3;


    public MucAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }


    @Override
    public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new DauSachFragment();
                case 1:
                    return new DocGiaFragment();
                default:
                    return new NhanVienFragment();
            }

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Đầu Sách";
                case 1:
                    return "Độc giả";
                default:
                    return "Nhân viên";
            }
    }


    @Override
    public int getCount() {
        BienToanCuc bienToanCuc = (BienToanCuc) mContext.getApplicationContext();
        if (bienToanCuc.getQuyenUser().equals("DG"))
            return 1;

        return NUM_ITEMS;
    }


    // Force a refresh of the page when a different fragment is displayed
    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }
}
