package com.example.admin.quan_ly_thu_vien.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.admin.quan_ly_thu_vien.R;
import com.example.admin.quan_ly_thu_vien.Retrofit2.APIUtils;
import com.example.admin.quan_ly_thu_vien.Retrofit2.DataClient;
import com.example.admin.quan_ly_thu_vien.activitys.BienToanCuc;
import com.example.admin.quan_ly_thu_vien.models.TacGia;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TacGiaFragment extends Fragment {

    private View rootView;
    private BienToanCuc bienToanCuc;
    private ArrayList<TacGia> dsTacGia;

    public TacGiaFragment() {
    }


    public ArrayList<TacGia> getDsTacGia() {
        return dsTacGia;
    }

    public void setDsTacGia(ArrayList<TacGia> dsTacGia) {
        this.dsTacGia = dsTacGia;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.sach_list, container, false);

        bienToanCuc = (BienToanCuc) getActivity().getApplicationContext();


        getDanhSachTacGia(dsTacGia);

        return rootView;
    }

    public void getDanhSachTacGia( ArrayList<TacGia> arrayList) {
        DataClient dataClient = APIUtils.getData();
        Call<List<TacGia>> call = dataClient.GetListTacGia("key");
        call.enqueue(new Callback<List<TacGia>>() {
            @Override
            public void onResponse(Call<List<TacGia>> call, Response<List<TacGia>> response) {
                ArrayList<TacGia> TacGiaArrayList = (ArrayList<TacGia>) response.body();
                if (TacGiaArrayList != null && TacGiaArrayList.size() > 0) {
                    themTacGia(TacGiaArrayList);
                }
            }

            @Override
            public void onFailure(Call<List<TacGia>> call, Throwable t) {

            }
        });
    }


    private void themTacGia(ArrayList<TacGia> TacGiaArrayList) {
        dsTacGia = new ArrayList<TacGia>();
        for (int i = 0; i < TacGiaArrayList.size(); i++) {
            TacGia TacGia = new TacGia(TacGiaArrayList.get(i).getMaTacGia(), TacGiaArrayList.get(i).getTenTacGia());
            if (TacGia != null)
                dsTacGia.add(TacGia);
        }



    }
}
