package com.example.admin.quan_ly_thu_vien.interfaces;

public interface ILoadmore {
    void onLoadMore();
}
