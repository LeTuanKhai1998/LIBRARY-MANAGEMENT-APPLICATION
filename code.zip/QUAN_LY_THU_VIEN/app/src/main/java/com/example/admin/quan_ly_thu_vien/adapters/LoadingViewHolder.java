package com.example.admin.quan_ly_thu_vien.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import com.example.admin.quan_ly_thu_vien.R;

class LoadingViewHolder extends RecyclerView.ViewHolder {

    public ProgressBar progressBar;

    public LoadingViewHolder(View itemView) {
        super(itemView);
        progressBar = (ProgressBar) itemView.findViewById(R.id.pbLoading);
        progressBar.setVisibility(View.GONE);


    }

}