package com.example.admin.quan_ly_thu_vien.interfaces;

public interface ItemTouchListenner {
    void onMove(int oldPosition, int newPosition);

    void swipe(int position, int direction);
}