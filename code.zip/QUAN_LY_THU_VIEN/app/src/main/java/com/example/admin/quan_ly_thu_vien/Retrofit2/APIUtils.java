package com.example.admin.quan_ly_thu_vien.Retrofit2;


//cung cấp đường dẫn ra
public class APIUtils {
        public static final String Base_Url = "http://172.16.0.234/QuanLyThuVien/";
//            public static final String Base_Url = "http://10.10.23.224/QuanLyThuVien/";
//    public static final String Base_Url = "http://letuankhai.000webhostapp.com/Server/";

    public static DataClient getData() {
        return RetrofitClient.getClient(Base_Url).create(DataClient.class);

    }
}
