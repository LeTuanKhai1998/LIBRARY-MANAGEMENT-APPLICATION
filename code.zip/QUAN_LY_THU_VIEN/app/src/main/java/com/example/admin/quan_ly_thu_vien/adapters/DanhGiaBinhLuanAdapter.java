package com.example.admin.quan_ly_thu_vien.adapters;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.quan_ly_thu_vien.R;
import com.example.admin.quan_ly_thu_vien.interfaces.ILoadmore;
import com.example.admin.quan_ly_thu_vien.models.DanhGiaBinhLuan;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


//class LoadingViewHolder extends RecyclerView.ViewHolder {
//
//    public ProgressBar progressBar;
//
//    public LoadingViewHolder(View itemView) {
//        super(itemView);
//        progressBar = (ProgressBar) itemView.findViewById(R.id.pbLoading);
//        progressBar.setVisibility(View.GONE);
//
//
//    }
//
//}

class DanhGiaBinhLuanViewHolder extends RecyclerView.ViewHolder {
    public TextView ten, ngay, soLuotThich, moTa;
    public RatingBar rbDanhGia;
    public ImageView anhNguoiDung, iconthich;


    public DanhGiaBinhLuanViewHolder(View itemView) {
        super(itemView);
        ten = itemView.findViewById(R.id.txtTenNguoiDungDanhGia);
        ngay = itemView.findViewById(R.id.txtNgayDang);
        soLuotThich = itemView.findViewById(R.id.txtSoNguoiThich);
        moTa = itemView.findViewById(R.id.txtNguoiDungBinhLuan);
        rbDanhGia = itemView.findViewById(R.id.rbNguoiDungDanhGia);
        anhNguoiDung = itemView.findViewById(R.id.imgAnhNguoiDungDanhGia);
        iconthich = itemView.findViewById(R.id.imgThichBinhLuan);
        soLuotThich.setVisibility(View.GONE);
    }


    public DanhGiaBinhLuanViewHolder(View itemView, TextView ten, TextView ngay, TextView soThich, TextView binhluan, RatingBar rbDanhGia, ImageView anhNguoiDung, ImageView iconthich) {
        super(itemView);
        this.ten = ten;
        this.ngay = ngay;
        this.soLuotThich = soThich;
        this.moTa = binhluan;
        this.rbDanhGia = rbDanhGia;
        this.anhNguoiDung = anhNguoiDung;
        this.iconthich = iconthich;
    }
}


public class DanhGiaBinhLuanAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<DanhGiaBinhLuan> danhGiaBinhLuanList;
    private final int VIEW_TYPE_ITEM = 0, VIEW_TYPE_LOADING = 1;
    ILoadmore loadMore;
    boolean isLoading;
    Activity activity;
    int visibleThreshold = 6;
    int lastVisibleItem, totalItemCount;


    public DanhGiaBinhLuanAdapter(RecyclerView recyclerView, final Activity activity, List<DanhGiaBinhLuan> danhGiaBinhLuanList) {
        this.danhGiaBinhLuanList = danhGiaBinhLuanList;
        this.activity = activity;

        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && (totalItemCount) <= (lastVisibleItem + visibleThreshold)) {
                    if (loadMore != null)
                        loadMore.onLoadMore();
                    isLoading = true;
                }

            }
        });
    }


    @Override
    public int getItemViewType(int position) {
        return danhGiaBinhLuanList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    public void setLoadMore(ILoadmore loadMore) {
        this.loadMore = loadMore;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_TYPE_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.danh_sach_danh_gia_binh_luan, parent, false);

            vh = new DanhGiaBinhLuanViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.loading, parent, false);

            vh = new LoadingViewHolder(v);
            ((LoadingViewHolder) vh).progressBar.setVisibility(View.VISIBLE);

        }
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof DanhGiaBinhLuanViewHolder) {
            DanhGiaBinhLuan binhLuan = danhGiaBinhLuanList.get(position);

            ((DanhGiaBinhLuanViewHolder) holder).ten.setText(binhLuan.getTenNguoiDung());
            ((DanhGiaBinhLuanViewHolder) holder).ngay.setText(binhLuan.getNgayDang());

                ((DanhGiaBinhLuanViewHolder) holder).soLuotThich.setText(binhLuan.getSoLuotThich()+"");

            ((DanhGiaBinhLuanViewHolder) holder).moTa.setText(binhLuan.getMoTa());
            Picasso.get().load(binhLuan.getAnhNguoiDung())
                    .fit()
                    .centerCrop()
                    .into(((DanhGiaBinhLuanViewHolder) holder).anhNguoiDung);

            ((DanhGiaBinhLuanViewHolder) holder).iconthich.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                }
            });
            ((DanhGiaBinhLuanViewHolder) holder).rbDanhGia.setRating(binhLuan.getSoDanhGia());
        } else if (holder instanceof LoadingViewHolder) {
            if(!isLoading)
            ((LoadingViewHolder) holder).progressBar.setVisibility(View.VISIBLE);
            ((LoadingViewHolder) holder).progressBar.setIndeterminate(true);


        }
    }


    @Override
    public int getItemCount() {
        return danhGiaBinhLuanList.size();
    }

    public void setLoaded() {
        isLoading = false;
    }


}